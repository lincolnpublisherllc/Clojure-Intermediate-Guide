(defrecord Html [body]
  Renderable (render [_] (str "<p>" body "</p>")))
