(let [s (Long/parseLong (str score))]
              (if (<= 0 s 100) s 0))
            (catch Exception _ 0))})
