(defn ok? [{:keys [name score]}]
  (and (string? name) (<= 0 score 100)))
