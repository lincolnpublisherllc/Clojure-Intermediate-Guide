(defrecord Physical [price weight]
