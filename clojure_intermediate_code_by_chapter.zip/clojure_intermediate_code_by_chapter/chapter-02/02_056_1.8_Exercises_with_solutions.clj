1.8 Exercises (with solutions)
