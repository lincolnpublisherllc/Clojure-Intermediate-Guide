(ns ingest.core
