(def sample
  ;; mix of good/bad lines
