(defmulti cost (fn [{:keys [type]}] type))
