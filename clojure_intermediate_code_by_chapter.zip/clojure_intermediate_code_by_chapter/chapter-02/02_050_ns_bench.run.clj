(ns bench.run
  (:require [criterium.core :as c]
            [refactor.csv :as seqp]
            [refactor.csv-xf :as xfp]))
