(defprotocol Priceable
  (cost [x]))
