(defn seq-pipeline [xs]
  (->> xs
       (map str/trim)
       (remove str/blank?)
       (map parse-row)
       (filter :ok)
       (into [])))
