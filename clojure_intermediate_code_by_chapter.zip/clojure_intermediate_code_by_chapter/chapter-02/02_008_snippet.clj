{
  :paths ["src" "resources"]
