Sequence destructuring silently drops or misses values when shapes drift. Prefer maps for options; use seq destructuring only for known, fixed arities (e.g., [a b & rest] in local helpers).
