(defn ingest!
