:test  {:extra-paths ["test"]
           :extra-deps  {org.clojure/test.check {:mvn/version "1.1.1"}}
