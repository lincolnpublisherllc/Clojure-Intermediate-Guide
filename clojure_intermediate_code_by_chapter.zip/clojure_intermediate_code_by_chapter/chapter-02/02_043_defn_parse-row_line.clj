(defn parse-row [line]
  ;; naive: "name,score"
  (let [[n s] (str/split line #"," 2)]
    (when (and n s (seq (str/trim n)) (re-matches #"-?\d+" (str/trim s)))
      {:name  (-> n str/trim)
       :score (Long/parseLong (str/trim s))})))
