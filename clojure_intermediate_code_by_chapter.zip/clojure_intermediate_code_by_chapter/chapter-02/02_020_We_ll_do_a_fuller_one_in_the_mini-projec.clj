(We’ll do a fuller one in the mini-project.)
(ns bench.run
  (:require [criterium.core :as c]
            [clojure.string :as str]))
