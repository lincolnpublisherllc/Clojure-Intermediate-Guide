;; Apply to a collection:
(into [] xf lines)
