(defn decorate [m]
  (assoc m :grade (cond
