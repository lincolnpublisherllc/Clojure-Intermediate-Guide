(defn xform-pipeline [xs]
  (into [] xf xs))
