1.3 Transducers vs sequences (practical)
