(defn normalize [{:keys [name score] :as m}]
  (let [score (or score 0)]
    {:name  (-> name str clojure.string/trim)
     :score (long score)
     :raw   m}))
