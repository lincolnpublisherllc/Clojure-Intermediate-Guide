(reduce (fn [acc x] (conj! acc (inc x)))
            (transient [])
