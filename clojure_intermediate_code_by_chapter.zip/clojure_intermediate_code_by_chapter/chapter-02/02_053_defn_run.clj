(defn run [_]
  (println "Seq pipeline:")
  (c/quick-bench (seqp/clean-seq sample))
  (println "Transducer pipeline:")
  (c/quick-bench (xfp/clean-xf sample)))
