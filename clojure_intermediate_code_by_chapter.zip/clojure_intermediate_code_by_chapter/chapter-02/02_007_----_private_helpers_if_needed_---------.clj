;; ---- private helpers (if needed) ------------------------------------------
;; (defn- parse-date ...) ; keep these below, keep public API obvious
Keep public entry points documented and minimal. Favor plain data arguments ({:keys [...]}) so you can evolve options without breaking call sites.
