(or (get-in m [:profile :city]) "Unknown")
;; or
(or (some-> m :profile :city) "Unknown")
