(defn build-fast [xs]
