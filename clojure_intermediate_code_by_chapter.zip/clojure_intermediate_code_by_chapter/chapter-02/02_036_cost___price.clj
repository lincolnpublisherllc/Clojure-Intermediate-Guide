(cost [_] price))
