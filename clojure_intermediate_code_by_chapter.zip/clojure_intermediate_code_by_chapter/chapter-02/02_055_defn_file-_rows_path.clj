(defn file->rows [path]
  (with-open [r (io/reader path)]
    (into [] csv-xf/xf (line-seq r))))
