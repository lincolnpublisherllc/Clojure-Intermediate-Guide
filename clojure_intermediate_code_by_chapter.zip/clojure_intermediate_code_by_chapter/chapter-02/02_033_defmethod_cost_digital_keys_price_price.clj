(defmethod cost :digital [{:keys [price]}] price)
(defmethod cost :physical [{:keys [price weight]}]
  (+ price (* 0.5 weight)))
(defmethod cost :default [_] 0)
