(defn clean-xf [lines]
  (into [] xf lines))
