(defn parse-row [s] (when (re-matches #"\w+,\d+" s) {:ok true :raw s}))
(def lines (repeat 50000 "alpha,42"))
