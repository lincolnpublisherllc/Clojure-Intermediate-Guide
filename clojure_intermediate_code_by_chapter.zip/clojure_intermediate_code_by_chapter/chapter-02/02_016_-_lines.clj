(->> lines
     (map str/trim)
     (remove str/blank?)
     (map parse-row)
     (filter :ok)
     (map decorate)
     (take 1000))
