(defn run [_]
  (println "Seq pipeline:")
  (c/quick-bench (seq-pipeline lines))
  (println "Xform pipeline:")
  (c/quick-bench (xform-pipeline lines)))
