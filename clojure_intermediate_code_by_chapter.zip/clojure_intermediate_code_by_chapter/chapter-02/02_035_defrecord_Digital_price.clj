(defrecord Digital [price]
