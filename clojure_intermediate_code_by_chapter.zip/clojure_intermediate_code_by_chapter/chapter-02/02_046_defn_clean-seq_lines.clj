(defn clean-seq [lines]
  (->> lines
       (map str/trim)
       (remove str/blank?)
       (map parse-row)
       (filter some?)
       (filter ok?)
       (map decorate)
       (into [])))
