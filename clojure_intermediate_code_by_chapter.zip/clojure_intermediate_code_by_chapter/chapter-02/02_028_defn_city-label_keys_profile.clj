(defn city-label [{:keys [profile]}]
  (let [{:keys [city]} profile]  ;; profile may be nil
    (or city "Unknown")))
