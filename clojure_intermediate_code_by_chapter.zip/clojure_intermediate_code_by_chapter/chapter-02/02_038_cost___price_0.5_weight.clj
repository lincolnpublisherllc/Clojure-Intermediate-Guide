(cost [_] (+ price (* 0.5 weight))))
