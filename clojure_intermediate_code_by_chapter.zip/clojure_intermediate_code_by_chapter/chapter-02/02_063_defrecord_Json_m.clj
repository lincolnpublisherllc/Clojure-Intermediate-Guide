(defrecord Json [m]
  Renderable (render [_] (pr-str m)))
