1.7.1 Starting point (sequence pipeline)
