(def xf (comp (map inc) (filter odd?)))
(transduce xf
           (completing (fn [acc x]
                         (if (< (count acc) 5) (conj acc x) (reduced acc))))
           []
