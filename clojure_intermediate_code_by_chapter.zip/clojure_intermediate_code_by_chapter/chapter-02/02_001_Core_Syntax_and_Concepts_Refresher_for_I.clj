Core Syntax and Concepts Refresher (for Intermediates)
