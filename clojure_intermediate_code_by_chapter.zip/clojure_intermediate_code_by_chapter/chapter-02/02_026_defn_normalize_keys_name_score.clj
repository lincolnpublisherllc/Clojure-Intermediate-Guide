(defn normalize [{:keys [name score]}]
  ;; if :score is nil, downstream math explodes
  {:name (str/trim name)
   :score (Long/parseLong (str score))})
