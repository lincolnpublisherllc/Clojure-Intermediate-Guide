[{:keys [src sink rules]}]
  (-> (io/line-source src)
      (v/validated-lines rules)
      (io/write-sink sink)))
