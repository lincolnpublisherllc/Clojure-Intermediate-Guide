:bench {:extra-deps {criterium/criterium {:mvn/version "0.4.6"}}
