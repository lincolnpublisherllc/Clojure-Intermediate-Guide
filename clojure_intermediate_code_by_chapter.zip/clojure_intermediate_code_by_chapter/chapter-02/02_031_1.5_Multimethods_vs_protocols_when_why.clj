1.5 Multimethods vs protocols (when/why)
