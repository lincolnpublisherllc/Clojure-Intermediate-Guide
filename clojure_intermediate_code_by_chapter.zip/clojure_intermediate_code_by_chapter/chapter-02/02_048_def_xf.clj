(def xf
  (comp
    (map str/trim)
    (remove str/blank?)
    (map base/parse-row)
    (filter some?)
    (filter base/ok?)
    (map base/decorate)))
