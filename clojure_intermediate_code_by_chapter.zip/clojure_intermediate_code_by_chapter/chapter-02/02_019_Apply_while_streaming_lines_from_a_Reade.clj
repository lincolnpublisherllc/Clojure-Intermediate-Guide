;; Apply while streaming lines from a Reader:
(transduce xf
           (completing conj)
           []
           (line-seq rdr))
