(defn normalize [{:keys [name score] :as m}]
  {:name  (let [n (some-> name str clojure.string/trim)]
            (if (seq n) n "<unknown>"))
