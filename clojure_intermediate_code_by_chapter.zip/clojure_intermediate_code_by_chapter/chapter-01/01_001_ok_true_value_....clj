{:ok true  :value ...}
{:ok false :error :timeout :context {...}}
