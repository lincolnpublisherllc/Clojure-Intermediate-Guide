(defrecord MemRepo [!emails]
