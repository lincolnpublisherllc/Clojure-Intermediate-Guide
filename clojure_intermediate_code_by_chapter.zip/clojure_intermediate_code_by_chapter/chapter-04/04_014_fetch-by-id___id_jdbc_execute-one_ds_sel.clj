(fetch-by-id [_ id] (jdbc/execute-one! ds ["select * from users where id=?" id]))
  (create!    [_ u]  (jdbc/execute-one! ds ["insert into users(name,email) values (?,?) returning *"
                                            (:name u) (:email u)]))
  (update!    [_ u]  (jdbc/execute-one! ds ["update users set name=?,email=? where id=? returning *"
                                            (:name u) (:email u) (:id u)])))
