app/                   ; entrypoints (CLI/HTTP/REPL)
