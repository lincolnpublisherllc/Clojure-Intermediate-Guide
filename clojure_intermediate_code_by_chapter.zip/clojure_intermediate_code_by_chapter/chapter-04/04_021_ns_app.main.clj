(ns app.main
  (:require [domain.user :as user]
            [adapters.db :as db]))
