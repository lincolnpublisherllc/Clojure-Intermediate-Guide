(ns internal.util)
(defn- parse-long* [s] (try (Long/parseLong (str s)) (catch Exception _ nil)))
