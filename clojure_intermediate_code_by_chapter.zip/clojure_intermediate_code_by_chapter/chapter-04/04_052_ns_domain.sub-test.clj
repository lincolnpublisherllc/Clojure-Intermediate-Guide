(ns domain.sub-test
  (:require [clojure.test :refer [deftest is]]
            [domain.sub :as S]
            [domain.sub.proto :as P]))
