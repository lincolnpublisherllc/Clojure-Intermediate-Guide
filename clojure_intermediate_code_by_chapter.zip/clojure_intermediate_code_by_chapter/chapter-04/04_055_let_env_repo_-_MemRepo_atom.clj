(let [env {:repo (->MemRepo (atom #{}))}]
    (is (:ok? (S/signup env {:name "Ada" :email "a@b.com"})))))
