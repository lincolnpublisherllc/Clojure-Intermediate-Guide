(defn run [{:keys [jdbc-url]}]
  (let [repo (->db/JdbcUserRepo (make-datasource jdbc-url))]
    (user/bootstrap! {:repo repo})))
