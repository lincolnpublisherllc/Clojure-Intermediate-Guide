3.12 Exercises (with solutions)
