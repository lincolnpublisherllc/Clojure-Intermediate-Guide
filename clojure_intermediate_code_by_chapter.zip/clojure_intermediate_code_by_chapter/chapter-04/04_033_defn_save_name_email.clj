(defn save! [name email]
  (jdbc/execute-one! ds ["insert into subs(name,email) values(?,?)" name email]))
