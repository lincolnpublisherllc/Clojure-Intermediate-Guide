(defn- valid? [{:keys [name email]}]
  (and (seq name) (re-matches #".+@.+" email)))
