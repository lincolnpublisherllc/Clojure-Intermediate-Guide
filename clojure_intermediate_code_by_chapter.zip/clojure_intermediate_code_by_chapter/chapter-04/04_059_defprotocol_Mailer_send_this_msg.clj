(defprotocol Mailer (send! [this msg]))
