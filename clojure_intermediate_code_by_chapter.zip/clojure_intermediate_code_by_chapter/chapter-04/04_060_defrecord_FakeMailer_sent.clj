(defrecord FakeMailer [!sent]
