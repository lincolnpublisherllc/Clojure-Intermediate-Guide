{:ok? false :error :already-exists}
          {:ok? true  :user (p/create! repo u*)})))))
