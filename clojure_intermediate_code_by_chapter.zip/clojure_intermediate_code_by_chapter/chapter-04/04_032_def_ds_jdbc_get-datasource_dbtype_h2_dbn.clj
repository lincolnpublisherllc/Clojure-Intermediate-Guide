(def ds (jdbc/get-datasource {:dbtype "h2" :dbname "mem"}))
