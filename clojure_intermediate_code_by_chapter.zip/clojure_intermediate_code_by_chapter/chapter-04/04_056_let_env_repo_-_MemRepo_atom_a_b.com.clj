(let [env {:repo (->MemRepo (atom #{"a@b.com"}))}]
    (is (false? (:ok? (S/signup env {:name "Ada" :email "a@b.com"}))))))
