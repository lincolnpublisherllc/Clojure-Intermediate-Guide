(defn run [{:keys [db name email]}]
  (let [ds   (jdbc/get-datasource db)
        env  {:repo (->repo/JdbcRepo ds)}
        res  (domain/signup env {:name name :email email})]
    (println (if (:ok? res) "OK" (str "ERR " (:error res))))
