3.9.1 Starting point (single namespace, mixed concerns)
(ns signup.core
  (:require [clojure.java.io :as io]
            [clojure.string :as str]
            [next.jdbc :as jdbc]))
