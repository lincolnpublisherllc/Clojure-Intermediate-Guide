(defrecord CachedRepo [delegate !emails]
