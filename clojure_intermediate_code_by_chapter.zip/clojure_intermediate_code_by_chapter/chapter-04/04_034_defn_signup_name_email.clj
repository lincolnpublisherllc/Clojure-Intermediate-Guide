(defn signup! [name email]
  (let [name (str/trim (str name))
        email (str/trim (str email))]
    (if (and (seq name) (re-matches #".+@.+" email))
      (do (save! name email) (println "Saved"))
      (println "Invalid"))))
