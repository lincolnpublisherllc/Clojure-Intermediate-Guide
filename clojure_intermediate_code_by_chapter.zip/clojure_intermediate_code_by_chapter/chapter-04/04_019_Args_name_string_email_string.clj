Args: {:name string, :email string}
