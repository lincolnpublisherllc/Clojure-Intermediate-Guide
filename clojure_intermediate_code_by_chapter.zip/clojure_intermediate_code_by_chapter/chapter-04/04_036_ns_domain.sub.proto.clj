(ns domain.sub.proto)
(defprotocol SubRepo
  (save! [this sub])
  (exists? [this email]))
