(exists? [_ email] (contains? @!emails email))
  (save! [_ sub] (swap! !emails conj (:email sub)) (assoc sub :id 1)))
