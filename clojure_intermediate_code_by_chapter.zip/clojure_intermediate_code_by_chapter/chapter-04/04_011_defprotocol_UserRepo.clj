(defprotocol UserRepo
  (fetch-by-id [this id])
  (create! [this user])
  (update! [this user]))
