(defn notify [{:keys [name email urgent?] :or {urgent? false}}]
  (if (and (seq name) (re-matches #".+@.+" (str email)))
    {:ok? true  :queued? (boolean urgent?)}
    {:ok? false :error :invalid}))
