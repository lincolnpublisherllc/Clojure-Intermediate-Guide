(defn create-user [name email flags timeout-ms] ...)
