Task: Replace (notify name email urgent?) with notify {:name .. :email .. :urgent? ..}. Provide defaults and return an envelope.
