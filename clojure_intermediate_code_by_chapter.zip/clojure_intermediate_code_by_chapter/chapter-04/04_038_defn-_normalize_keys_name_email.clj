(defn- normalize [{:keys [name email]}]
  {:name (-> name str str/trim)
   :email (-> email str str/trim)})
