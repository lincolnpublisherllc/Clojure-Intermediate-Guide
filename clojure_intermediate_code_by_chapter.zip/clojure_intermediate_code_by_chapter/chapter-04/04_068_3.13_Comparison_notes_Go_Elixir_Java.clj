3.13 Comparison notes (Go, Elixir, Java)
