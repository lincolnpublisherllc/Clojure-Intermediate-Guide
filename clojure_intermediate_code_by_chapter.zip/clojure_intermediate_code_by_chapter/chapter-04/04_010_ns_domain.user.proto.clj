(ns domain.user.proto)
