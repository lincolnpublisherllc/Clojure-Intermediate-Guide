(defn- normalize [{:keys [name email] :as u}]
  {:name  (-> name str str/trim)
   :email (-> email str str/trim)})
