3.8.1 Domain rules (pure)
(ns domain.user
