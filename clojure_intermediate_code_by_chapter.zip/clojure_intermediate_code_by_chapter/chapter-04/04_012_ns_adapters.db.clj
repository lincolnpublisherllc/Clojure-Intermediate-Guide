(ns adapters.db
  (:require [domain.user.proto :as p]
            [next.jdbc :as jdbc]))
