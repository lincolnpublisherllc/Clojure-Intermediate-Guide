3.9.6 Step 5 — HTTP entrypoint (optional)
