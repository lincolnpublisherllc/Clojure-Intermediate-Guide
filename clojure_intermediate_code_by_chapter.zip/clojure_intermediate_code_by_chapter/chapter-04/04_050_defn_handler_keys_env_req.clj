(defn handler [{:keys [env]} req]
  (let [{:keys [name email]} (:params req)
        res (domain/signup env {:name name :email email})]
    (if (:ok? res)
      (-> (r/response {:status "ok" :sub (:sub res)}) (r/content-type "application/json"))
      (-> (r/response {:status "error" :error (:error res)}) (r/status 400)))))
