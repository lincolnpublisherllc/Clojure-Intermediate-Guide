{:ok? true  :value ...}
{:ok? false :error :not-found :context {...}}
