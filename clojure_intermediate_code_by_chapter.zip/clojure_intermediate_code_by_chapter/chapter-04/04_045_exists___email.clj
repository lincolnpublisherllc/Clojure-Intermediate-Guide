(exists? [_ email]
    (some? (jdbc/execute-one! ds ["select 1 from subs where email=?" email])))
  (save! [_ {:keys [name email]}]
    (jdbc/execute-one! ds ["insert into subs(name,email) values(?,?) returning id,name,email"
                           name email])))
