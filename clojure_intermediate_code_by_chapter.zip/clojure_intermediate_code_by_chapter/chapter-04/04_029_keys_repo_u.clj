[{:keys [repo]} u]
  (let [u* (normalize u)]
    (if-not (valid? u*)
      {:ok? false :error :invalid}
      (let [existing (p/fetch-by-id repo (:id u*))]
