3.9.2 Step 1 — Define a port (protocol)
