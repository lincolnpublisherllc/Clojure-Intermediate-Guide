(ns adapters.email
  (:require [clojure.string :as str]
            [domain.user.proto :as p]))
