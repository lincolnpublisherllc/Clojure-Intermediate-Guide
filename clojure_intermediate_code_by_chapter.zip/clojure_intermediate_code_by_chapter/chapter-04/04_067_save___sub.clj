(save! [_ sub]
    (let [s (p/save! delegate sub)]
      (swap! !emails conj (:email s))
