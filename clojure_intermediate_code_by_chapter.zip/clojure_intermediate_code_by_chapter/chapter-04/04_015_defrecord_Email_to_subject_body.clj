(defrecord Email [to subject body])
;; Behaves like a map: (:to (->Email "a@b" "hi" "body"))
