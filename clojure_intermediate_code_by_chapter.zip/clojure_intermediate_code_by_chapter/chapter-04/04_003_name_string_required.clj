:name    string (required)
   :email   string (required)
   :flags   set of keywords (optional)
