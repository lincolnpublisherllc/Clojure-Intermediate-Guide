(ns app.cli
  (:require [domain.sub :as domain]
            [adapters.jdbc-repo :as repo]
            [next.jdbc :as jdbc]))
