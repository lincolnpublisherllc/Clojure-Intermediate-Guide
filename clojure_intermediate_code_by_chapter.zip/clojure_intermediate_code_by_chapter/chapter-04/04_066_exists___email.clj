(exists? [_ email]
    (or (contains? @!emails email)
        (let [e (p/exists? delegate email)]
          (when e (swap! !emails conj email))
