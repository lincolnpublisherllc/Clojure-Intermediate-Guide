domain/                ; business logic (pure)
