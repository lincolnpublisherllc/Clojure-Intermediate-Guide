3.11 Common mistakes (and simple fixes)
