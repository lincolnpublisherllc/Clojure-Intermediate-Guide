(not (valid? sub*))  {:ok? false :error :invalid}
      (p/exists? repo (:email sub*)) {:ok? false :error :duplicate}
      :else {:ok? true :sub (p/save! repo sub*)})))
