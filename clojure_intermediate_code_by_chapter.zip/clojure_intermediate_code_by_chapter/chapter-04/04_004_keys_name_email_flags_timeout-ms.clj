[{:keys [name email flags timeout-ms]
    :or   {flags #{}, timeout-ms 1000}}]
  ;; return {:ok? true :user {...}} or {:ok? false :error ...}
