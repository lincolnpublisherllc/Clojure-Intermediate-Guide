(ns adapters.jdbc-repo
  (:require [domain.sub.proto :as p]
            [next.jdbc :as jdbc]))
