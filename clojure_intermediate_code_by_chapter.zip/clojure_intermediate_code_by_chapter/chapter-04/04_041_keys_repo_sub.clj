[{:keys [repo]} sub]
  (let [sub* (normalize sub)]
