(defn run [{:keys [db port] :or {port 8080}}]
  (let [ds   (jdbc/get-datasource db)
        env  {:repo (->repo/JdbcRepo ds)}]
    (jetty/run-jetty #(handler {:env env} %) {:port port :join? false})))
