Clojure Intermediate Guide — Extracted Code by Chapter
Source: /mnt/data/Clojure Intermediate Guide.docx
Extraction mode: python-docx

Chapter 01: INTRODUCTION — 1 snippets
Chapter 02: Chapter 1 - Core Syntax and Concepts Refresher (for Intermediates) — 63 snippets
Chapter 03: Chapter 2 - Project Environment and Package Management — 53 snippets
Chapter 04: Chapter 3 - Functions, Modules, and Code Organisation at Scale — 68 snippets
Chapter 05: Chapter 4 - Data Structures in Depth (Sets, Maps, Trees, Tuples) — 49 snippets
Chapter 06: Chapter 5 - File Handling and Working with External Data — 77 snippets
Chapter 07: Chapter 6 - Error Handling, Testing Frameworks, and Debugging Practices — 58 snippets
Chapter 08: Chapter 7 - Concurrency and Parallelism (Threads, Actors, Async Models) — 50 snippets
Chapter 09: Chapter 8 - Functional + Interop Patterns (OOP Edges on the JVM) — 55 snippets
Chapter 10: Chapter 9 - Using Libraries and Ecosystem Tools — 81 snippets
Chapter 11: Chapter 10 - Building a Mid-Sized Project (REST API / CLI / Simulation) — 71 snippets
Chapter 12: Chapter 11 - Integration with Databases and External Services — 55 snippets
Chapter 13: Chapter 12 - Optimisation Techniques and Memory Profiling — 29 snippets
Chapter 14: Chapter 13 - Intermediate Best Practices: Clean Code, Documentation, Maintainability — 18 snippets
Chapter 15: Chapter 14 - Case Study: Building a Fintech Ledger in Clojure — 31 snippets
Chapter 16: CONCLUSION — 1 snippets

Total snippets: 760
