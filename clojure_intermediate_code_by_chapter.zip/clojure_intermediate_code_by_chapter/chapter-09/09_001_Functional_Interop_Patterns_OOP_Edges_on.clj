Functional + Interop Patterns (OOP Edges on the JVM)
