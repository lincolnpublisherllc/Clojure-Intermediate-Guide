(defn new-client [opts] (jdk/client opts))
