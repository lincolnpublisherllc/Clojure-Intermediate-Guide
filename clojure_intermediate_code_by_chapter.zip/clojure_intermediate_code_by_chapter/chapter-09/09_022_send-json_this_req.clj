(send-json! [this req]
    (let [r (p/send! this (update req :headers conj "Accept" "application/json"))]
      (if (:ok r)
