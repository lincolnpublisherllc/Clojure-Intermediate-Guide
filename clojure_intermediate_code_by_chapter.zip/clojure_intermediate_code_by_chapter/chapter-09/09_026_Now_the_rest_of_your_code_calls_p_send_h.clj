Now the rest of your code calls (p/send! http {:method "GET" :url "…" ...}) and always gets a data envelope.
