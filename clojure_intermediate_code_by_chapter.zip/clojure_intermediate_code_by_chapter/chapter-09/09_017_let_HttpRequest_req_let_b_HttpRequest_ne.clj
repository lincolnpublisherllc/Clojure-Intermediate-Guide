(let [^HttpRequest req (let [b (HttpRequest/newBuilder (URI/create url))]
                               (doseq [[k v] (partition 2 (or headers []))]
                                 (.header b k v))
                               (.method b (or method "GET")
