(assoc r :value (update (:value r) :body #(json/read-str % :key-fn keyword)))
