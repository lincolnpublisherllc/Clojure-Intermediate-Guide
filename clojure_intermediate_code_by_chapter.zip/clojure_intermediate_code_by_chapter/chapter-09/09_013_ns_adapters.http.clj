(ns adapters.http
  (:refer-clojure :exclude [send])
  (:require [ports.http :as p]
            [clojure.data.json :as json])
  (:import (java.net.http HttpClient HttpRequest HttpResponse)
           (java.net URI)
           (java.time Duration)))
