(HttpRequest$BodyPublishers/ofString ^String body)
                                          (HttpRequest$BodyPublishers/noBody)))
                               (.timeout b (Duration/ofMillis timeout-ms))
                               (.build b))
            ^HttpResponse resp (.send client req (HttpResponse$BodyHandlers/ofString))]
        {:ok true
         :value {:status (.statusCode resp)
                 :headers (into {} (.map (.headers resp)))
                 :body (.body resp)}})
