;; assert retry logic, envelope mapping, and header normalization
