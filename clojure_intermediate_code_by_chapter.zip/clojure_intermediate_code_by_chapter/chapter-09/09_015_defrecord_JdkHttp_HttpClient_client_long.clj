(defrecord JdkHttp [^HttpClient client ^long timeout-ms]
