(with-open [in (java.io.FileInputStream. path)]
      (let [buf (byte-array (.available in))]
        (.read in buf)
        {:ok true :value buf}))
    (catch java.io.FileNotFoundException _ {:ok false :error :not-found})))
