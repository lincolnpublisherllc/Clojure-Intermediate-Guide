(defn make-request [^HttpRequest$Builder b] (.build b))
