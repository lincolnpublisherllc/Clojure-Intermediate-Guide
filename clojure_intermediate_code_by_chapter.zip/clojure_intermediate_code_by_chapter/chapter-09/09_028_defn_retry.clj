(defn retry
  [n f {:keys [base-ms] :or {base-ms 50}}]
  (loop [i 0]
    (let [r (f)]
      (if (or (:ok r) (>= i n) (not= :timeout (:error r)))
