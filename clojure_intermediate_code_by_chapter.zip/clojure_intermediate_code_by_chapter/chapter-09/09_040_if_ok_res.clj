(if (:ok res)
  (println "Rate limit:" (get-in res [:value :headers "x-ratelimit-remaining"]))
  (println "HTTP error:" (:error res)))
