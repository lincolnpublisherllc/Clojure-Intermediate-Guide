(defn build-request
  [{:keys [^String method ^String url headers body]
    :or   {method "GET" headers []}}]
  (let [^HttpRequest$Builder b (-> (HttpRequest/newBuilder (URI/create url))
