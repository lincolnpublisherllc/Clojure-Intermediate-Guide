accepts data ({:method :get :url "...":headers [...]:body "..."})
returns envelopes ({:ok true :value {:status 200 :headers {...} :body "..."}})
