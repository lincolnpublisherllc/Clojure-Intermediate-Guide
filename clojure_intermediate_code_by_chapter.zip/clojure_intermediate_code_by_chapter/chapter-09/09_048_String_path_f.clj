[^String path f]
  (with-open [s (lines path)]
    (doseq [^String line (.iterator s)]
      (let [row (str/split line #",")]
        (f (mapv str/trim row))))))
