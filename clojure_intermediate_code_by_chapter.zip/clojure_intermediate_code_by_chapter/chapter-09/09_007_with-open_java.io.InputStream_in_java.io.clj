(with-open [^java.io.InputStream in (java.io.FileInputStream. "data.bin")]
  ;; consume fully here
  (let [buf (byte-array 8192)]
    (loop [acc 0]
      (let [n (.read in buf)]
        (if (pos? n)
          (recur (+ acc n))
