(import '(java.util Arrays))
(Arrays/asList (object-array [1 2 3]))     ;; varargs sometimes need arrays
