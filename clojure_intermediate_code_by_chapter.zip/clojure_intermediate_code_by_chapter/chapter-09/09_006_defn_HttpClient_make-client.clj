(defn ^HttpClient make-client
  [{:keys [^long connect-timeout-ms]}]
  (-> (HttpClient/newBuilder)
      (.connectTimeout (java.time.Duration/ofMillis connect-timeout-ms))
      (.build)))
