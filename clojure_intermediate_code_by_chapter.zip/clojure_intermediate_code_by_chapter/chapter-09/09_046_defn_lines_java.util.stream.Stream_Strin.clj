(defn lines ^java.util.stream.Stream [^String path]
  (Files/lines (Paths/get path (make-array String 0)) StandardCharsets/UTF_8))
