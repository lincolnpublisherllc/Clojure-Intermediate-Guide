8.6 Records as data-backed types (when to use them)
