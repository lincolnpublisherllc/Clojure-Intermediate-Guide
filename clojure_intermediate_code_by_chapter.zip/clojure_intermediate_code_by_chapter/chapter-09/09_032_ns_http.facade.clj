(ns http.facade
  (:require [ports.http :as p]
            [adapters.http :as jdk]))
