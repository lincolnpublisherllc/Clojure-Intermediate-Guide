{:client c :req {...} :retries 2 :json? true}"
  [{:keys [client req retries json?] :or {retries 0 json? false}}]
  (let [send-fn (if json? #(p/send-json! client %) #(p/send! client %))]
    (loop [i 0]
      (let [r (send-fn req)]
        (if (and (false? (:ok r)) (= :timeout (:error r)) (< i retries))
          (do (Thread/sleep (* 50 (inc i))) (recur (inc i)))
