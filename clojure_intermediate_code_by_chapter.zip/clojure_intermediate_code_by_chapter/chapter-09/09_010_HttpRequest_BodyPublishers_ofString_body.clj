(HttpRequest$BodyPublishers/ofString body)
                                              (HttpRequest$BodyPublishers/noBody))))]
    (doseq [[k v] (partition 2 headers)]
      (.header b k v))
    (.build b)))
