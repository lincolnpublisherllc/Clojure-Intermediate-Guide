8.9.1 Port and adapter (recap)
