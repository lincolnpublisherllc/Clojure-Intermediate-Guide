8.11 Practical exercises (with solutions)
