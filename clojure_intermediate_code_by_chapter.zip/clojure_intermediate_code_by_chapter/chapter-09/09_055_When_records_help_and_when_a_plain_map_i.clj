When records help (and when a plain map is better)
