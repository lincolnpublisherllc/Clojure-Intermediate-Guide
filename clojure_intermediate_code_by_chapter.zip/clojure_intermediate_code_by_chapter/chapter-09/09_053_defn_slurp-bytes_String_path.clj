(defn slurp-bytes [^String path]
