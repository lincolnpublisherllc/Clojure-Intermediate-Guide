(def http (http.facade/new-client {:connect-timeout-ms 1500
                                   {:request-timeout-ms 4000}}))
