(defn client
  [{:keys [^long connect-timeout-ms ^long request-timeout-ms]
    :or   {connect-timeout-ms 2000 request-timeout-ms 5000}}]
  (->JdkHttp
   (-> (HttpClient/newBuilder)
       (.connectTimeout (Duration/ofMillis connect-timeout-ms))
       (.build))
