(ns adapters.http
  (:refer-clojure :exclude [send])
  (:import (java.net.http HttpClient HttpRequest HttpResponse)
           (java.net URI))
  (:require [clojure.string :as str]))
