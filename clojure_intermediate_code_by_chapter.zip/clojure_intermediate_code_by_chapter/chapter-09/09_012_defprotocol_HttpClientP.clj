(defprotocol HttpClientP
  (send! [this req] "Sync request; returns envelope")
  (send-json! [this req] "As above, parse JSON to data"))
