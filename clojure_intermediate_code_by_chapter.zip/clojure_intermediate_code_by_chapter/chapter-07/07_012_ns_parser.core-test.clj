(ns parser.core-test
  (:require [clojure.test :refer [deftest is testing]]
            [parser.core :as p]))
