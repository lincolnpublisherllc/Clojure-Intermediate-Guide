6.12 Practical exercises (with solutions)
