6.2 Turn exceptions into data (result envelopes)
