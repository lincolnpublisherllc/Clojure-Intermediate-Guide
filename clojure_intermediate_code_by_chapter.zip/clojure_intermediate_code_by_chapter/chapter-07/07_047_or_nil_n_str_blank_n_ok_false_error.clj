(or (nil? n*) (str/blank? n*)) {:ok false :error :invalid :reason :missing-name :raw line}
      (not (re-matches #"-?\d+" (str s*))) {:ok false :error :invalid :reason :bad-score :raw line}
      :else {:ok true :value {:name n* :score (Long/parseLong s*)}})))
6.11.4 Ingest (stream, validate, metrics, retry)
(ns harden.ingest
  (:require [harden.core :as core]
            [clojure.java.io :as io]))
