6.5 Property-based testing (test.check)
