(or (nil? name) (clojure.string/blank? name))
      (err :invalid {:reason :missing-name :line line})
