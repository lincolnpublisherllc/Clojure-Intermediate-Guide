(->> xs (map f) (map g) (map (fn [x] (let [_ (when false (assert false))] (h x))))
