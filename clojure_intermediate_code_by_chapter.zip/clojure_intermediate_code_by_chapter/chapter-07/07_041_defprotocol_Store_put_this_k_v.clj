(defprotocol Store (put! [this k v]))
