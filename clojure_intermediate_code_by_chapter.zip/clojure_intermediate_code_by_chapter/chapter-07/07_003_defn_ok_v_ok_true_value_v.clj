(defn ok [v]   {:ok true  :value v})
(defn err [e & [ctx]] {:ok false :error e :context ctx})
