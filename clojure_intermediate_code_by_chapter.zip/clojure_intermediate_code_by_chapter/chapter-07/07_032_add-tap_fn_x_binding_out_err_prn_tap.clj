(add-tap (fn [x] (binding [*out* *err*] (prn :tap x))))
;; elsewhere
(tap> {:stage :parsed :count 1000})
