6.11.3 Core (parse + envelope)
(ns harden.core
  (:require [clojure.string :as str]))
