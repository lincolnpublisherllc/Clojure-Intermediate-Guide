(defn try* [thunk]
  (try (ok (thunk))
       (catch java.io.FileNotFoundException e (err :not-found {:ex e}))
       (catch java.net.SocketTimeoutException e (err :timeout {:ex e}))
       (catch Exception e (err :unknown {:ex e}))))
