(defn with-tmp-dir [f]
  (let [d (java.nio.file.Files/createTempDirectory "t" (make-array java.nio.file.attribute.FileAttribute 0))]
    (try (binding [*tmp-dir* d] (f))
         (finally (clojure.java.io/delete-file (.toFile d) true)))))
