(defn dbg [tag x] (tap> {:tag tag :sample (pr-str (take 3 (if (sequential? x) x [x])))}) x)
