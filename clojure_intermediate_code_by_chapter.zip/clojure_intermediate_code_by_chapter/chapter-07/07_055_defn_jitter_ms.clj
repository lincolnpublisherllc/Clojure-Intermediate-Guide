(defn jitter [ms]
  (let [r (+ 0.8 (* 0.4 (.nextDouble (java.util.Random.))))]
    (long (* ms r))))
