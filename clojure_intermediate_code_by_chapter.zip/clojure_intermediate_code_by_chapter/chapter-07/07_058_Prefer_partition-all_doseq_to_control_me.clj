(Prefer partition-all + doseq to control memory.)
