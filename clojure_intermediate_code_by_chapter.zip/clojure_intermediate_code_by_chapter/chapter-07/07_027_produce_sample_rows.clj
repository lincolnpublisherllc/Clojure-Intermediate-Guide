;; produce sample rows
(take 3 (repeatedly gen-row))
