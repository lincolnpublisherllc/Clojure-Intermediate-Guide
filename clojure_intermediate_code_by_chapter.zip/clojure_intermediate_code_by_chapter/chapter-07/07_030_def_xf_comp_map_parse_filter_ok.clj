(def xf (comp (map parse) (filter :ok)))
(def out (into [] (eduction xf (line-seq rdr))))
