(defn ingest! [{:keys [in sink retry-n incident?]}]
  (let [!seen (atom 0) !ok (atom 0) !bad (atom 0)]
    (with-open [r (io/reader in)]
      (doseq [line (line-seq r)]
        (swap! !seen inc)
        (let [r (core/parse-row line)]
          (if (:ok r)
            (let [row (:value r)
                  attempt (fn [] (sink row) :ok)
                  res (loop [i 0]
                        (try (attempt)
