(= ::bad score)
      (err :invalid {:reason :bad-score :line line})
