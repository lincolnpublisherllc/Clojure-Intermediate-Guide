(ok (clojure.edn/read-string value))
      (err error {:path path}))))
