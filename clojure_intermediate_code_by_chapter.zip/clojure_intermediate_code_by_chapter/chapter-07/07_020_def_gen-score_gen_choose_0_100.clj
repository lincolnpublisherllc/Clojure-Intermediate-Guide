(def gen-score (gen/choose 0 100))
