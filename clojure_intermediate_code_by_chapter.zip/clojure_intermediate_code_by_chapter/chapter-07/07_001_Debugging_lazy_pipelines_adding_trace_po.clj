Debugging lazy pipelines, adding trace points (tap>, logging)
