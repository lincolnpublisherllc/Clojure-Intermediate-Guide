(def gen-name
  (gen/fmap #(-> % str/trim (subs 0 (min 10 (count %))))
            (gen/string-alphanumeric)))
