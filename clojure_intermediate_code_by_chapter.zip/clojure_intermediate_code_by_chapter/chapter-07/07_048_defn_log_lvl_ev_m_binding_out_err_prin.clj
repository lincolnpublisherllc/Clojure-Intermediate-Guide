(defn log! [lvl ev m] (binding [*out* *err*] (println (pr-str (merge {:level lvl :event ev} m)))))
