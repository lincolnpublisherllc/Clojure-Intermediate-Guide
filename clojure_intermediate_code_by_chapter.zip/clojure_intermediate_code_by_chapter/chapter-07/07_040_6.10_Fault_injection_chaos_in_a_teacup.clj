6.10 Fault injection (chaos in a teacup)
