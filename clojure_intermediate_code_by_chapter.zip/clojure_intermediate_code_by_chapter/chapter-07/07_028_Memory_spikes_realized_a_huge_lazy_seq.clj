Memory spikes (realized a huge lazy seq)
