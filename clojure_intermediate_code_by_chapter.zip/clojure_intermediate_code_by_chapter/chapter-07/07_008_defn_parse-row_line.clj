(defn parse-row [line]
  ;; "name,score"
  (let [[n s] (clojure.string/split line #"," 2)
        name (some-> n clojure.string/trim)
        score (parse-int* s)]
