(defn log! [level event m]
  (println (pr-str (merge {:ts (System/currentTimeMillis)
