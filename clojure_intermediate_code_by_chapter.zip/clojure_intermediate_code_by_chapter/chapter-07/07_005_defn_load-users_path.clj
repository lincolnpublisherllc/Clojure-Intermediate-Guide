(defn load-users [path]
  (let [{:keys [ok value error]} (try* #(slurp path))]
