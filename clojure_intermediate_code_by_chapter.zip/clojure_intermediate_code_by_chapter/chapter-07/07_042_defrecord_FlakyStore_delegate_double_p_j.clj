(defrecord FlakyStore [delegate ^double p ^java.util.Random rnd]
