(log! :info :import-start {:in "data.csv" :pid (.pid (ProcessHandle/current))})
(log! :warn :invalid-row {:line n :reason :bad-score})
