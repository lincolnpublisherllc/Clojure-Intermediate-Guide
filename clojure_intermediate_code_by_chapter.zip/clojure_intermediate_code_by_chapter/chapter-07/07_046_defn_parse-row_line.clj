(defn parse-row [line]
  (let [[n s] (str/split line #"," 2)
        n* (some-> n str/trim)
        s* (some-> s str/trim)]
