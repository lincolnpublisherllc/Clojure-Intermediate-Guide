(defn flaky-sink [^double p]
  (let [rnd (java.util.Random.)]
    (fn [row]
      (when (< (.nextDouble rnd) p)
        (throw (ex-info "simulated-io-failure" {:row row})))
      ;; pretend to write somewhere
