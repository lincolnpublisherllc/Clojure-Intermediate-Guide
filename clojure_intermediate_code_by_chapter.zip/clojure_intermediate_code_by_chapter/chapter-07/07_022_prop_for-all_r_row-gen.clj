(prop/for-all [r row-gen]
    (:ok (p/parse-row r))))
