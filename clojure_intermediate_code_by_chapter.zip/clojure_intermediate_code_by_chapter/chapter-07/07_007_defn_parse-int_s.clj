(defn parse-int* [s]
  (try (Integer/parseInt (str s))
       (catch Exception _ ::bad)))
