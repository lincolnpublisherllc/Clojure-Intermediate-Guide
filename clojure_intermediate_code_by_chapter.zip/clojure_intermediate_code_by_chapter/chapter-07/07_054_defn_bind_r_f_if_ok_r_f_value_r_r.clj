(defn bind [r f] (if (:ok r) (f (:value r)) r))
;; (-> (try* fa) (bind fb) (bind fc))
