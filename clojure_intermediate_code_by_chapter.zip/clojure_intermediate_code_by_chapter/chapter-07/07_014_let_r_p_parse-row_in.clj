(let [r (p/parse-row in)]
        (is (= (:ok r) (:ok exp)))
        (when (:ok r)
          (is (= (:value r) (:value exp))))
        (when-not (:ok r)
          (is (= (:error r) (:error exp))))))))
6.4.2 Fixtures (per test / once)
(ns support.fixtures
  (:require [clojure.test :refer [use-fixtures]]))
