(defn with-timeout [ms f]
  (let [ft (future (f))]
    (let [v (deref ft ms ::timeout)]
      (if (= v ::timeout)
        (do (future-cancel ft) (err :timeout {:ms ms}))
        (ok v)))))
