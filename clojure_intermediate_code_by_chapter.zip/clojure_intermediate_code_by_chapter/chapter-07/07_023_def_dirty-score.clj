(def dirty-score
  (gen/one-of [gen-score (gen/string) (gen/elements ["" "NaN" " "])]))
