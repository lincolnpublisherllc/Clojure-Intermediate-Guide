(put! [_ k v]
    (if (< (.nextDouble rnd) p)
      (throw (ex-info "boom" {:where :put! :k k}))
      (put! delegate k v))))
