:else (ok {:name name :score score}))))
