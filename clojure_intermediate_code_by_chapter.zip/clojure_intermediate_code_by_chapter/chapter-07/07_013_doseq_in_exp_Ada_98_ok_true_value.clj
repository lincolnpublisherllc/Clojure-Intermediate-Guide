(doseq [[in exp] { "Ada,98"   {:ok true  :value {:name "Ada" :score 98}}
                     " ,98"     {:ok false :error :invalid}
                     "Bo,abc"   {:ok false :error :invalid}
                     "Chi,77"   {:ok true  :value {:name "Chi" :score 77}}}]
