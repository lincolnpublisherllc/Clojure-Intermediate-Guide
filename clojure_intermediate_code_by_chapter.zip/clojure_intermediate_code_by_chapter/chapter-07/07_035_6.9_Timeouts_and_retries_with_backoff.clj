6.9 Timeouts and retries (with backoff)
