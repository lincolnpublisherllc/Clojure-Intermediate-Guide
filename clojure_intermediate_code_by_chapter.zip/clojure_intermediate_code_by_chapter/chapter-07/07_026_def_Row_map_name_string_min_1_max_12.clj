(def Row [:map [:name [:string {:min 1 :max 12}]]
               [:score [:int {:min 0 :max 100}]]])
(def gen-row (mg/generator Row))
