[n f {:keys [base-ms] :or {base-ms 50}}]
  (loop [i 0]
    (let [r (try* f)]
      (if (or (:ok r) (>= i n) (not (#{{:timeout true} :timeout} (:error r))))
