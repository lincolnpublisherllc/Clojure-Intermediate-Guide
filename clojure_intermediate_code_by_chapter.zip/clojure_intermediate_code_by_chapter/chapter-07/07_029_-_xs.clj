(->> xs
     (map f)
     (partition-all 1000)
     (map (fn [chunk] (do (tap> {:stage :after-f :n (count chunk)})
                          (doall chunk))))
     (run! g))
