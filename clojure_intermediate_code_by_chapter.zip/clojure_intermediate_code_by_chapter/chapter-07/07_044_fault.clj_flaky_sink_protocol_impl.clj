fault.clj     ; flaky sink (protocol impl)
