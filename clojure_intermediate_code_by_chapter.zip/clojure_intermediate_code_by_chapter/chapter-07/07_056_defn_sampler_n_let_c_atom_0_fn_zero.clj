(defn sampler [n] (let [c (atom 0)] (fn [] (zero? (mod (swap! c inc) n)))))
(def sample? (sampler 1000))
(when (sample?) (tap> {:stage :parsed :count 1000}))
