(def row-gen
  (gen/fmap (fn [[n s]] (str n "," s))
            (gen/tuple gen-name gen-score)))
