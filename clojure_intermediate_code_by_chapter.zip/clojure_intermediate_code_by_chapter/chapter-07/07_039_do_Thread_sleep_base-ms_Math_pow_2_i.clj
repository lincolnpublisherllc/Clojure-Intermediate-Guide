(do (Thread/sleep (* base-ms (Math/pow 2 i)))
            (recur (inc i)))))))
