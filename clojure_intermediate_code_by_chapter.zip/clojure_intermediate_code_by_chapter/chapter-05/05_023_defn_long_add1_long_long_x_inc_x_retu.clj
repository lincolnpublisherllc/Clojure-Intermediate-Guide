(defn ^long add1 ^long [^long x] (inc x))  ;; return + args hints
