;; [:tuple int? int?] ;; readable, fast validation (if you use malli)
