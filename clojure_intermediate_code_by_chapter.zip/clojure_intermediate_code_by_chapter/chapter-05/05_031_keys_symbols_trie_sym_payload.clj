[{:keys [symbols trie]} sym payload]
  (let [sym (str sym)]
    (->Index
      (update symbols sym (fnil conj []) payload)
      (insert-trie trie sym))))
