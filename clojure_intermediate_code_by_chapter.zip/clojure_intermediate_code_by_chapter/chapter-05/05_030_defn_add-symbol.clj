(defn add-symbol
