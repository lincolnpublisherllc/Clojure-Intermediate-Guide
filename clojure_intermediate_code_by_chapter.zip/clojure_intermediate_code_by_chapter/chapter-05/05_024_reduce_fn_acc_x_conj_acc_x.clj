(reduce (fn [acc x] (conj! acc x))
          (transient [])
