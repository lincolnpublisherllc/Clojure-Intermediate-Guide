(when (:end? node) [prefix])
      (mapcat (fn [[c child]] (walk-node child (str prefix c)))
              (:kids node)))))
