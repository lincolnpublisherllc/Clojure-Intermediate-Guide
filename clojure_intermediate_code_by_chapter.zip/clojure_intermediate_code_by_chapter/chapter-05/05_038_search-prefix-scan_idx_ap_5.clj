(search-prefix-scan idx "ap" 5)
;; => ({:sym "apex"  ...} {:sym "apple" ...} {:sym "apply" ...})
