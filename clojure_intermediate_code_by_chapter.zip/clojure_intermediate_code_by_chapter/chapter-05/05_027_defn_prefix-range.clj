(defn prefix-range
