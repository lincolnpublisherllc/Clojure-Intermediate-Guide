(search idx prefix {:limit n :mode :scan|:trie}) → results
