4.10 Comparison notes (Go, Elixir, Java)
