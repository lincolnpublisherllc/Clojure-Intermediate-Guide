(let [loc (fs-zip fs)
      src (-> loc z/down)]         ;; first child (src)
  (-> src
      (z/append-child {:name "util.clj"})
