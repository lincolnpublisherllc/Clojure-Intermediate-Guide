(group-by :city [{:n "Ada" :city "Lagos"} {:n "Bo" :city "Abuja"}])
