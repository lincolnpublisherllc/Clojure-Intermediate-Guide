(def fs
  {:name "/"
   :children [{:name "src" :children [{:name "core.clj"}]}
              {:name "test" :children []}]})
