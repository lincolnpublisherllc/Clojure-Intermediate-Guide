4.9 Practical exercises (with solutions)
