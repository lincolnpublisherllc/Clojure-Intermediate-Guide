;; Or, unique lookup:
(into {} (map (juxt :id identity) coll))  ;; {id -> record}
