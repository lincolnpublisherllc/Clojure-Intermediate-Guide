(def ci-compare
  (fn [^String a ^String b]
    (let [la (.toLowerCase a)
          lb (.toLowerCase b)]
      (compare la lb))))
