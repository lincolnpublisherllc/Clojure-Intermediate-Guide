4.5 Tuples via vectors + validation (spec/malli)
