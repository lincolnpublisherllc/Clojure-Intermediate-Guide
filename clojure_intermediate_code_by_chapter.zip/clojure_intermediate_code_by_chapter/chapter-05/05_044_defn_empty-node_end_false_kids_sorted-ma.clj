(defn empty-node [] {:end? false :kids (sorted-map) :count 0})
