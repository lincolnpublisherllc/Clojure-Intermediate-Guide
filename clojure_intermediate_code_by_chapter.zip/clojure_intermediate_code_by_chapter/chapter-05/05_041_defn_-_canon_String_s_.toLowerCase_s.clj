(defn ->canon [^String s] (.toLowerCase s))
(defn add! [s username] (conj s (->canon username)))
(defn member? [s username] (contains? s (->canon username)))
