(fn branch? [node] (seq (:children node)))
   (fn children [node] (:children node))
   (fn make-node [node kids] (assoc node :children (vec kids)))
