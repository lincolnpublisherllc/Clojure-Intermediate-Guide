(defn search-prefix-scan [{:keys [symbols]} prefix limit]
  (->> (prefix-range symbols prefix)
       (mapcat (fn [[k vs]] (map (fn [v] {:sym k :payload v}) vs)))
       (take limit)))
