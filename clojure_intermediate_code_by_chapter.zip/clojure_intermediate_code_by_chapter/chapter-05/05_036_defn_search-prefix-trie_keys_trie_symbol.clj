(defn search-prefix-trie [{:keys [trie symbols]} prefix limit]
  ;; Walk to the node for `prefix`, then collect words
  (let [chars (seq prefix)]
    (loop [n trie, cs chars]
      (if-let [c (first cs)]
        (if-let [child (get-in n [:kids c])]
          (recur child (rest cs))
          [])
        ;; at prefix node; gather terminals and map to payloads
        (->> (walk-node n prefix)
             (mapcat (fn [sym] (map (fn [v] {:sym sym :payload v})
                                    (get symbols sym))))
             (take limit))))))
