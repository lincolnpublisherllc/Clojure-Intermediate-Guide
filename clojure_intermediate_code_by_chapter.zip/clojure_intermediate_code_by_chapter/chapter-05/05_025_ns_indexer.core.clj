(ns indexer.core
  (:require [clojure.string :as str]))
