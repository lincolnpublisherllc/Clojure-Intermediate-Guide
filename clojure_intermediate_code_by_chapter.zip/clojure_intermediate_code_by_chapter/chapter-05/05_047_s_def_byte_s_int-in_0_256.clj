(s/def ::byte (s/int-in 0 256))
(s/def ::rgb (s/and vector? #(= 4 (count %))
                    (fn [[tag r g b]]
                      (and (= tag :rgb) (every? #(s/valid? ::byte %) [r g b])))))
