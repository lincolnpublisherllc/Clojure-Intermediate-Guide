(def users (-> #{} (add! "Ada") (add! "bo")))
