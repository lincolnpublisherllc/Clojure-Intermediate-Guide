[^clojure.lang.Sorted sm ^String prefix]
  (let [from prefix
        ;; choose an upper bound just after the prefix in lexicographic space
        to   (str prefix Character/MAX_VALUE)]
    (subseq sm >= from < to)))
4.8.3 Trie helpers (kids sorted for predictable order)
(defn empty-node []
  {:end? false
   :kids (sorted-map)})
