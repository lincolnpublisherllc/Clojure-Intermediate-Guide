(search-prefix-trie idx "ap" 5)
;; similar order since kids are sorted
