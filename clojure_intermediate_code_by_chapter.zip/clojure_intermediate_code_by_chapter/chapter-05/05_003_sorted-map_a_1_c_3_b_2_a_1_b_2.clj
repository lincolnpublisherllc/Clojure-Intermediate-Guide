(sorted-map :a 1 :c 3 :b 2)    ;; => {:a 1, :b 2, :c 3}
(sorted-set 5 3 7 1)           ;; => #{1 3 5 7}
