(def users (sorted-map-by ci-compare
