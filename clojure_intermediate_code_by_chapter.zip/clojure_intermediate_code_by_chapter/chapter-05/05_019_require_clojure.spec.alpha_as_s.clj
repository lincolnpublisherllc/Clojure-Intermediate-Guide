(require '[clojure.spec.alpha :as s])
(s/def ::int int?)
(s/def ::point (s/and vector? #(= 2 (count %))
                      (fn [[x y]] (and (int? x) (int? y)))))
