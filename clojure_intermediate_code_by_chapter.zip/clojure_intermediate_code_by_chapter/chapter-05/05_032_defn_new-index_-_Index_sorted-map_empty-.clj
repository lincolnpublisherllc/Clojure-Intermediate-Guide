(defn new-index [] (->Index (sorted-map) (empty-node)))
4.8.5 Prefix search (two paths)
