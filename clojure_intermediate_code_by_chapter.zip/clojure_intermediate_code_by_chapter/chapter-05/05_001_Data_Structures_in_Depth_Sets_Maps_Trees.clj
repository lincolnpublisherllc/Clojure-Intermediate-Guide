Data Structures in Depth (Sets, Maps, Trees, Tuples)
