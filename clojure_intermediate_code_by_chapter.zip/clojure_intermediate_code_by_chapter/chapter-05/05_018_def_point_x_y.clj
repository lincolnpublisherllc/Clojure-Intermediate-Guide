(def point [x y])
(let [[x y] point] (+ x y))
