(defn insert-trie [node ^String s]
  (let [chars (seq s)]
    (loop [n node, cs chars]
      (if-let [c (first cs)]
        (let [child (get-in n [:kids c] (empty-node))]
          (recur (update n :kids assoc c (insert-trie child (apply str (rest cs))))
                 (rest cs)))
        (assoc n :end? true)))))
