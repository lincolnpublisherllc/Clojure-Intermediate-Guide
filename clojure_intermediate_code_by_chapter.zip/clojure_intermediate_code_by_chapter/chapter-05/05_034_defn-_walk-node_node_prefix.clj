(defn- walk-node [node prefix]
