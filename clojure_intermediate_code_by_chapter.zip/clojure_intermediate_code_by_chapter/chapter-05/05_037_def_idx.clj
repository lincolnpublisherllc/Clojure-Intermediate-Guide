(def idx
  (-> (new-index)
      (add-symbol "apply" {:file "core.clj" :line 10})
      (add-symbol "apple" {:file "ds.clj"   :line 22})
      (add-symbol "apex"  {:file "ds.clj"   :line 7})
      (add-symbol "banana" {:file "lex.clj" :line 1})))
