(defn insert-trie [node s]
  (let [chars (seq s)]
    (loop [n node, cs chars]
      (if-let [c (first cs)]
        (let [child (get-in n [:kids c] (empty-node))
              child' (insert-trie child (apply str (rest cs)))]
          (-> n
              (assoc-in [:kids c] child')
              (update :count inc)))
        (-> n (assoc :end? true) (update :count inc))))))
