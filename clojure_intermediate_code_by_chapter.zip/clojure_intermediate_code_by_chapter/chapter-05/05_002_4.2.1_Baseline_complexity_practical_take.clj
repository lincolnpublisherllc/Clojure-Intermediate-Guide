4.2.1 Baseline complexity (practical take)
