(assoc-in user [:profile :city] "Abuja")
(update-in stats [:counts "A"] (fnil inc 0))
(get-in cfg [:db :pool] 10)  ;; default: 10
