(def sm (into (sorted-map)
              (map (fn [s] [s (count s)]))
              ["apple" "apex" "apply" "banana" "band"]))
