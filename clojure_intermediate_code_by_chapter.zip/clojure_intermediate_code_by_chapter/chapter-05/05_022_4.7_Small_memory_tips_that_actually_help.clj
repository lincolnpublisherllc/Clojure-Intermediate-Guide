4.7 Small memory tips (that actually help)
