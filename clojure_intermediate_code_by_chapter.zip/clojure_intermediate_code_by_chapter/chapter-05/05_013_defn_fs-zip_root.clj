(defn fs-zip [root]
