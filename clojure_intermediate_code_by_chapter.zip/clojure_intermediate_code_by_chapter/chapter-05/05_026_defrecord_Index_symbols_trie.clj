(defrecord Index [symbols trie])
;; symbols: sorted-map symbol -> payloads (vector)
;; trie: nested map {:end? bool, :kids (sorted-map char node)}
