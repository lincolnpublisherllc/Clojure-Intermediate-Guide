(def seen (transient #{}))
