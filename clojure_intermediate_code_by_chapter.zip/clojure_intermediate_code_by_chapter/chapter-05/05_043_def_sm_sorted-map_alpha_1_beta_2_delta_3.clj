(def sm (sorted-map "alpha" 1 "beta" 2 "delta" 3 "beacon" 4))
(into {} (subseq sm >= "be" < "bf"))  ;; => {"beacon" 4, "beta" 2}
