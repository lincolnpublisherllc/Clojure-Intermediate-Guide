(defn read-csv-rows
