By business key (group, region, etc.)
