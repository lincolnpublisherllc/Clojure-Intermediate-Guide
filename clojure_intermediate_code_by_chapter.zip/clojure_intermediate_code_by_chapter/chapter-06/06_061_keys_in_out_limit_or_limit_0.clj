[{:keys [in out limit] :or {limit 0}}]
  (when-not (and in out) (throw (ex-info "Need :in and :out" {})))
  (p/ensure-dir! out)
  (let [!ok    (atom 0)
        !bad   (atom 0)
        !seen  (atom 0)
        cap?   (fn [] (and (pos? limit) (>= @!seen limit)))
        handle (fn [m]
                 (when-not (cap?)
                   (swap! !seen inc)
                   (let [{:keys [ok row norm error]} (v/check m)]
