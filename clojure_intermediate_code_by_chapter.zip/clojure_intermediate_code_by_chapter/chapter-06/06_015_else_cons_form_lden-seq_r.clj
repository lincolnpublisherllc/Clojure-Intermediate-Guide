:else          (cons form (lden-seq r)))))))
