(defn write-lines
