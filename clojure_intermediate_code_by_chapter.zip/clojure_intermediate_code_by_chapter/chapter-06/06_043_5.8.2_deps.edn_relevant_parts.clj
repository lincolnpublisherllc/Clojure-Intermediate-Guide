5.8.2 deps.edn (relevant parts)
{
 :paths ["src"]
 :deps {org.clojure/clojure {:mvn/version "1.11.3"}
        org.clojure/data.csv {:mvn/version "1.1.0"}
        metosin/malli {:mvn/version "0.14.0"}}
