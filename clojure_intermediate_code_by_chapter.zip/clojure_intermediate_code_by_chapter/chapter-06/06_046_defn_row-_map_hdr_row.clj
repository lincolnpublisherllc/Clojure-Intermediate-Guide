(defn row->map [hdr row]
  (zipmap hdr (map str/trim row)))
