(defn jsonl->edn! [in out]
  (with-open [r (io/reader in)]
    (let [lines (line-seq r)]
      (doseq [[ix chunk] (map-indexed vector (partition-all 1000 lines))]
        (let [path (str out "/part-" ix ".edn")]
          (with-open [w (io/writer path)]
            (doseq [l chunk]
              (.write w (pr-str (json/read-str l :key-fn keyword)))
              (.write w "\n"))))))))
