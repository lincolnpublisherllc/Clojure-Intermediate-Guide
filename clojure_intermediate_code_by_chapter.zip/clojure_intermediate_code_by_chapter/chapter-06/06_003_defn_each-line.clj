(defn each-line
