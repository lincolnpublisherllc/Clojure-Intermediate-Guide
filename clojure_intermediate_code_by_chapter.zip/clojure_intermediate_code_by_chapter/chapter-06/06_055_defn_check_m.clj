(defn check [m]
  (let [m* (normalize m)]
    (if (valid? m*)
      {:ok true  :row m*}
      {:ok false :error :invalid :raw m :norm m*})))
5.8.5 Partitioned EDN writer (import/partition.clj)
