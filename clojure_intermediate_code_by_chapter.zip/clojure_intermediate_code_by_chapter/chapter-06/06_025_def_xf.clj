(def xf
  (comp
    (map str/trim)
    (remove str/blank?)
    (map parse-row)
    (filter some?)))
