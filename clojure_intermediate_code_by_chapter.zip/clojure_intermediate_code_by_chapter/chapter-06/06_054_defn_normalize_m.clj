(defn normalize [m]
  (-> m
      (update :name #(-> % str str/trim))
      (update :score #(try (Long/parseLong (str %)) (catch Exception _ -1)))))
