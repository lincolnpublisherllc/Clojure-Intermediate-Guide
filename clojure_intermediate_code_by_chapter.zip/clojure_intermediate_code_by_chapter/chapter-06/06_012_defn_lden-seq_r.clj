(defn lden-seq [r]
  (let [pbr (java.io.PushbackReader. r)]
