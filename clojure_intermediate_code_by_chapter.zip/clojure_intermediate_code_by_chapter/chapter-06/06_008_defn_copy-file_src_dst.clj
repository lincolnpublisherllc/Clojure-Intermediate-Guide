(defn copy-file! [src dst]
  (Files/copy (Paths/get src (make-array String 0))
              (Paths/get dst (make-array String 0))
              (into-array StandardCopyOption [StandardCopyOption/REPLACE_EXISTING])))
