(when (zero? (mod @!seen 10000))
  (println "Progress:" {:seen @!seen :ok @!ok :bad @!bad}))
