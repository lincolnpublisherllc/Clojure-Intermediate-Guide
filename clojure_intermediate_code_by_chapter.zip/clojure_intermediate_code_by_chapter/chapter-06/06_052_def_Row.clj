(def Row
  [:map
   [:name [:and string? [:fn (comp pos? count str/trim)]]]
   [:score [:int {:min 0 :max 100}]]
   [:group [:maybe [:enum "A" "B" "C" "D" "E"]]]])
