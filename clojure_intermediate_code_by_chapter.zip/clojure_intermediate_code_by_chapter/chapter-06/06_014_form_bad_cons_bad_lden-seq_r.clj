(= form ::bad) (cons ::bad (lden-seq r))
