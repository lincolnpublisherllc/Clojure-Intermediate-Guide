(defn file-size [path]
  (Files/size (Paths/get path (make-array String 0))))
