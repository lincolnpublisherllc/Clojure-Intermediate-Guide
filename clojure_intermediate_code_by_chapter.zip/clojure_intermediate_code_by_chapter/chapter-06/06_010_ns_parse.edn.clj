(ns parse.edn
  (:require [clojure.edn :as edn]
            [clojure.java.io :as io]))
