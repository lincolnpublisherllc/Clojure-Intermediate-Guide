(defn append-edn! [path value]
  (with-open [w (io/writer path :append true)]
    (.write w (pr-str value))
    (.write w "\n")))
5.8.6 CLI runner (import/cli.clj)
(ns import.cli
  (:require [import.csv :as csv]
            [import.validate :as v]
            [import.partition :as p]
            [clojure.string :as str]))
