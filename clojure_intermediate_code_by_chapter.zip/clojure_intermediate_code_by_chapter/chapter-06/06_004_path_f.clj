[path f]
  (with-open [r (io/reader path)]
    (doseq [line (line-seq r)]
      (f line))))
