(defn classify-row [m]
  (if (and (string? (:name m)) (number? (:score m)))
    {:ok true  :row m}
    {:ok false :error :invalid-row :raw m}))
