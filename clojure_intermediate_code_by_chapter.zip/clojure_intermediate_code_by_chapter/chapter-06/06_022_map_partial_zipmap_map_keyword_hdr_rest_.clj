(map (partial zipmap (map keyword hdr)) (rest rows'))))
        (doall rows')))))
