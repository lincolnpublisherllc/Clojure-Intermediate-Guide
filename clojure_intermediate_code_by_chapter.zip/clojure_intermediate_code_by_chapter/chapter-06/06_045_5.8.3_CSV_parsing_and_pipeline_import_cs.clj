5.8.3 CSV parsing and pipeline (import/csv.clj)
(ns import.csv
  (:require [clojure.java.io :as io]
            [clojure.data.csv :as csv]
            [clojure.string :as str]))
