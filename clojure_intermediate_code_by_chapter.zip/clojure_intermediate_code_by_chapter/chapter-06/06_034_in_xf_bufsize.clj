[in xf bufsize]
  (let [out (a/chan bufsize xf)]
