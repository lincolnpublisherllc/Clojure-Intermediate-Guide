5.10 Exercises (with solutions)
