(defn collect [lines] (into [] xf lines))
