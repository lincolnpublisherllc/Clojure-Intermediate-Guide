(loop [ok 0 bad 0]
               (if-let [msg (a/<! out-ch)]
                 (if (:ok msg)
                   (do (p/append-edn! (p/path-for out (:group (:row msg))) (:row msg))
                       (recur (inc ok) bad))
                   (do (p/append-edn! (p/path-for out "errors") (dissoc msg :ok))
                       (recur ok (inc bad))))
                 {:ok ok :bad bad}))))))
