(ns ingest.pipeline
  (:require [clojure.string :as str]))
