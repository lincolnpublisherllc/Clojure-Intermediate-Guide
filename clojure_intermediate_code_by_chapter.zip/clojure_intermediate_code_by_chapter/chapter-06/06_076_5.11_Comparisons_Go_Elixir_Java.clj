5.11 Comparisons (Go, Elixir, Java)
