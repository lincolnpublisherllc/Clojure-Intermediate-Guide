(defn file->chan
