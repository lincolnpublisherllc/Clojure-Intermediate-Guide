[path]
  (with-open [r (io/reader path)]
    (let [rs (csv/read-csv r)
          hdr (mapv keyword (map str/trim (first rs)))]
      ;; realize all rows HERE or process inside with-open
      (doall (map (partial row->map hdr) (rest rs))))))
