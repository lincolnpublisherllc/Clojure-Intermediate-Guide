(s/def ::name (s/and string? #(seq %)))
(s/def ::score (s/int-in 0 101))
(s/def ::row (s/keys :req-un [::name ::score]))
