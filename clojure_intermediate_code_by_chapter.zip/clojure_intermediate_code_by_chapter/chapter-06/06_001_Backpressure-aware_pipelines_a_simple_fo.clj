Backpressure-aware pipelines (a simple form with core.async)
