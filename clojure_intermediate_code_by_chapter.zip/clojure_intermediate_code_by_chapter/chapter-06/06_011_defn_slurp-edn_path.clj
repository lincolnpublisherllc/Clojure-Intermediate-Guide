(defn slurp-edn [path]
  (with-open [r (io/reader path)]
    (edn/read (java.io.PushbackReader. r))))
