[path lines]
  (with-open [w (io/writer path)]
    (doseq [line lines]
      (.write w (str line "\n")))))
