(defn path-for [outdir group]
  (str (io/file outdir (str "part-" (or group "UNK") ".edn"))))
