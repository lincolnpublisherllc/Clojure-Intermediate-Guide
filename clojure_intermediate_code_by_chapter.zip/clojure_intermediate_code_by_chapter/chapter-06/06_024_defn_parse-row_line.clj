(defn parse-row [line]
  ;; "name,score" -> {:name .. :score ..} or nil if invalid
  (let [[n s] (str/split line #"," 2)
        n* (some-> n str/trim)
        s* (some-> s str/trim)]
    (when (and (seq n*) (re-matches #"-?\d+" s*))
      {:name n* :score (Long/parseLong s*)})))
