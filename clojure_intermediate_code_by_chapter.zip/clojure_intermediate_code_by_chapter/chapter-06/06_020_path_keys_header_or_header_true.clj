[path {:keys [header?] :or {header? true}}]
  (with-open [r (io/reader path)]
    (let [rows (csv/read-csv r)
          rows' (map #(map str/trim %) rows)]
