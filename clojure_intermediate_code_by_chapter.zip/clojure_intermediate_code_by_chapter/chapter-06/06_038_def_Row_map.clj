(def Row [:map
          [:name [:and string? [:fn (comp pos? count)]]]
          [:score [:int {:min 0 :max 100}]]])
