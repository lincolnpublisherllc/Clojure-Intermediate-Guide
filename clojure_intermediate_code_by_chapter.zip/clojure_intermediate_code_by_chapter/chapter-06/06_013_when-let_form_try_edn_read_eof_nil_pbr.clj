(when-let [form (try (edn/read {:eof nil} pbr)
                           (catch Exception _ ::bad))]
