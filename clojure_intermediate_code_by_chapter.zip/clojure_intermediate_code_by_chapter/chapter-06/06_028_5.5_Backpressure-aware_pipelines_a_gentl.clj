5.5 Backpressure-aware pipelines (a gentle core.async)
