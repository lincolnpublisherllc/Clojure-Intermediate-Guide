By date (e.g., part-2025-09-21.edn)
