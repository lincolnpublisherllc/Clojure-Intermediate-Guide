(defn ensure-dir! [^String dir]
  (.mkdirs (io/file dir)))
