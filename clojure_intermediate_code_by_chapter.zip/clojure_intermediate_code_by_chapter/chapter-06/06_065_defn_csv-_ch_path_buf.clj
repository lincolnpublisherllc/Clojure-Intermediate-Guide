(defn csv->ch [path buf]
  (let [ch (a/chan buf)]
