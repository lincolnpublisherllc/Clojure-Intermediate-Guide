(ns ingest.async
  (:require [clojure.core.async :as a]
            [clojure.java.io :as io]
            [clojure.string :as str]))
