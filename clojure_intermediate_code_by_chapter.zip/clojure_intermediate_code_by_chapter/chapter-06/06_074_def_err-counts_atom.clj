(def !err-counts (atom {}))
(defn capped-log! [out {:keys [error] :as msg}]
  (let [n (get (swap! !err-counts update error (fnil inc 0)) error)]
    (when (<= n 100)
      (p/append-edn! (p/path-for out "errors") msg))))
