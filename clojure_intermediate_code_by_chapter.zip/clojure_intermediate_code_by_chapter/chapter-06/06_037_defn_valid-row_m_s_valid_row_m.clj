(defn valid-row? [m] (s/valid? ::row m))
5.6.2 malli (concise, fast)
(ns ingest.malli
  (:require [malli.core :as m]))
