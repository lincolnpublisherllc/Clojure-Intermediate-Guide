(ns ingest.validate
  (:require [clojure.spec.alpha :as s]))
