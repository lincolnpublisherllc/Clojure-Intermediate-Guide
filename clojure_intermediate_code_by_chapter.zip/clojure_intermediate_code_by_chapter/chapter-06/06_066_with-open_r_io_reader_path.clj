(with-open [r (io/reader path)]
        (let [rs (csv/read-csv r)
              hdr (mapv keyword (first rs))]
          (doseq [row (rest rs)]
            (a/>!! ch (zipmap hdr row)))))
      (a/close! ch))
