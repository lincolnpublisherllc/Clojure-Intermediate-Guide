(defn run-async [{:keys [in out] :or {out "out"}}]
  (p/ensure-dir! out)
  (let [in-ch (csv->ch in 1024)
        out-ch (a/chan 1024 (comp (map v/check)))]  ;; transducer on channel
    (a/pipeline-blocking 4 out-ch (map identity) in-ch)
