(defn stream-file [path]
  (with-open [r (clojure.java.io/reader path)]
    (into [] xf (line-seq r))))
