(defn split-ok [xs]
  [(filter :ok xs) (remove :ok xs)])
