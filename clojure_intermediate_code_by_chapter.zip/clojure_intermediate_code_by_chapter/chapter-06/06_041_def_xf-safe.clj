(def xf-safe
  (comp
    (map classify-row)))
