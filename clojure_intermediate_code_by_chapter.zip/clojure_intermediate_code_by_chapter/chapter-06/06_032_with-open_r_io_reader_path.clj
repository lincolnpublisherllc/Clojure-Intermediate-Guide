(with-open [r (io/reader path)]
        (doseq [line (line-seq r)]
          (a/>!! ch line)))
      (a/close! ch))
