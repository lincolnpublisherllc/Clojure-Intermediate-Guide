(defn slurp-json [path]
  (with-open [r (io/reader path)]
    (json/read r :key-fn keyword)))
