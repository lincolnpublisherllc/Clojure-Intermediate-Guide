[path f]
  (with-open [r (io/reader path)]
    (let [rs (csv/read-csv r)
          hdr (mapv keyword (map str/trim (first rs)))]
      (doseq [row (rest rs)]
        (f (row->map hdr row))))))
5.8.4 Validation (import/validate.clj)
