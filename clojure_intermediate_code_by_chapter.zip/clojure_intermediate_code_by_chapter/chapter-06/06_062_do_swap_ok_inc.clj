(do (swap! !ok inc)
                           (p/append-edn! (p/path-for out (:group row)) row))
                       (do (swap! !bad inc)
                           (p/append-edn! (p/path-for out "errors")
                                          {:error (str error) :raw m :norm norm}))))))]
    ;; streaming inside with-open
    (csv/process-csv! in handle)
    (let [summary {:seen @!seen :ok @!ok :bad @!bad}]
      (println "Import complete:" summary)
