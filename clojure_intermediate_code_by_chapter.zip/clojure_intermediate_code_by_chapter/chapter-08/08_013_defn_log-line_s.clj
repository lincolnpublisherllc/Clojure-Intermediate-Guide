(defn log-line! [s]
  (send sink (fn [xs]
               (let [xs' (conj xs s)]
                 (if (>= (count xs') 100)
                   (do (flush! xs') [])
