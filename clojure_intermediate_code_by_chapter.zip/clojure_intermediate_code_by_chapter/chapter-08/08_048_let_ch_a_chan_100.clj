(let [ch (a/chan 100)
      start (System/currentTimeMillis)]
  (future (dotimes [i 10000] (a/>!! ch i)) (a/close! ch))
  (a/<!! (a/go (loop [] (when-let [x (a/<! ch)] (Thread/sleep 1) (recur)))))
  (- (System/currentTimeMillis) start))
