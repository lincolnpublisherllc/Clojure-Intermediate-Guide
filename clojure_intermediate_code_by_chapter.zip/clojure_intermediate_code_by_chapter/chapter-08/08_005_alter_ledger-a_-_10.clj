(alter ledger-a - 10)
  (alter ledger-b + 10))
