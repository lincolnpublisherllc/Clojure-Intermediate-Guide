(def summary (atom {:files 0 :bytes 0 :by-ext {} :errors 0}))
