(proxy [SimpleFileVisitor] []
       (visitFile [^Path p ^BasicFileAttributes attrs]
         (when (.isRegularFile attrs)
           (a/>!! in-ch (.toFile p)))
