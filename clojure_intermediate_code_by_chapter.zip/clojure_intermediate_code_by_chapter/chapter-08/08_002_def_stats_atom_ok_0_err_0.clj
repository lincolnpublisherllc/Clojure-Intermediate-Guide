(def stats (atom {:ok 0 :err 0}))
