(walk-files! root in-ch)
                   (finally (a/close! in-ch))))
        ;; collector
