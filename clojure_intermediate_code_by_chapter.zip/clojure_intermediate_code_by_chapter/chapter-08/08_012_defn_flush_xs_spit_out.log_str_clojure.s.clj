(defn flush! [xs] (spit "out.log" (str (clojure.string/join "\n" xs) "\n") :append true))
