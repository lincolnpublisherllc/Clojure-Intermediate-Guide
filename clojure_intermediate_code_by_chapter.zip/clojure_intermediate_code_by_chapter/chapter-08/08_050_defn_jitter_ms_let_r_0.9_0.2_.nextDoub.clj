(defn jitter [ms] (let [r (+ 0.9 (* 0.2 (.nextDouble (java.util.Random.))))] (long (* ms r))))
(defn retry [n f] (loop [i 0] (try (f) (catch Exception e (if (< i n) (do (Thread/sleep (jitter (bit-shift-left 50 i))) (recur (inc i))) (throw e))))))
