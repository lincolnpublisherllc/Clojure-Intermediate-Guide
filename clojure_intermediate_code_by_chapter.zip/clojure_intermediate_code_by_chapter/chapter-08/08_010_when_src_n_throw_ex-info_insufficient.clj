(when (< @src n) (throw (ex-info "insufficient" {:need n :have @src})))
    (alter src - n)
    (alter dst + n)))
