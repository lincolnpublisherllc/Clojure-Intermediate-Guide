(defn file-info [^java.io.File f]
  (let [name (.getName f)
        ext  (let [i (.lastIndexOf name ".")]
               (when (pos? i) (str/lower-case (subs name (inc i)))))]
    {:path (.getAbsolutePath f)
     :ext  (or ext "__noext")
     :bytes (.length f)
     :sha  (sha256-file f)}))
