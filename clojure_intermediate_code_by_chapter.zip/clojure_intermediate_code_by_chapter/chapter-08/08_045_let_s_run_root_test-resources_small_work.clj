(let [s (run {:root "test-resources/small" :workers 2 :buf 8})
        sum (reduce + (map (comp :b val) (:by-ext s)))]
    (is (= sum (:bytes s)))))
