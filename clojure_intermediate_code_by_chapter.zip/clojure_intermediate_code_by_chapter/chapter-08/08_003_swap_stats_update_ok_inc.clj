(swap! stats update :ok inc)
(reset! stats {:ok 0 :err 0})
