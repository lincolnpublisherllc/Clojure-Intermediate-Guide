(defn drain! [ch]
  (loop [acc 0]
    (if-let [_ (a/<!! ch)]
      (recur (inc acc))
