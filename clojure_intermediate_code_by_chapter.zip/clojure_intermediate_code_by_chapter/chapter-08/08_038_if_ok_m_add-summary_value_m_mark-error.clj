(if (:ok m) (add-summary! (:value m)) (mark-error!))
                       (recur))
                     :done)))]
    ;; when pipeline finishes, close out
    (future
