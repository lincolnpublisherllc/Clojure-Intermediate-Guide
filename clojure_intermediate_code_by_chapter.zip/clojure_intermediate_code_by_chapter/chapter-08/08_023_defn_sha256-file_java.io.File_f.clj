(defn sha256-file [^java.io.File f]
  (with-open [in (java.io.BufferedInputStream. (io/input-stream f))]
    (let [buf (byte-array 8192)
          md (MessageDigest/getInstance "SHA-256")]
      (loop []
        (let [n (.read in buf)]
          (when (pos? n)
            (.update md buf 0 n)
            (recur))))
      (format "%064x" (BigInteger. 1 (.digest md))))))
