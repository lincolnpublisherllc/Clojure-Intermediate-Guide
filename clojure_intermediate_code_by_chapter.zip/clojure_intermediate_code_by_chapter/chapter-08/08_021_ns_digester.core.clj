(ns digester.core
  (:require [clojure.core.async :as a]
            [clojure.java.io :as io]
            [clojure.string :as str])
  (:import (java.security MessageDigest)
           (java.nio.file Files Path Paths SimpleFileVisitor FileVisitResult)
           (java.nio.file.attribute BasicFileAttributes)))
