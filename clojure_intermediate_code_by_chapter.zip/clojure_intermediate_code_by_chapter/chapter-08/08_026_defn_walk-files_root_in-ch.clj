(defn walk-files! [root in-ch]
  (let [start (Paths/get root (make-array String 0))]
