(def metrics (atom {:seen 0 :ok 0 :err 0}))
(defn mark! [k] (swap! metrics update k inc))
