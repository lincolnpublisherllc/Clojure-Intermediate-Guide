7.11 Exercises (with solutions)
