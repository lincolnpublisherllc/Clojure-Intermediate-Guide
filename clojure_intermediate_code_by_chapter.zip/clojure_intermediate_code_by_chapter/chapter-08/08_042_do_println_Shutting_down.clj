#(do (println "Shutting down…")
       ;; close in-ch / flush agents etc.
