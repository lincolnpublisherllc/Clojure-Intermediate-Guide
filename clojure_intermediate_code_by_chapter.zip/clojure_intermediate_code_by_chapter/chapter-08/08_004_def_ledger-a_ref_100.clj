(def ledger-a (ref 100))
(def ledger-b (ref 50))
