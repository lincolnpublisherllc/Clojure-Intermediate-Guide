(when (zero? (mod (:files @summary) 1000))
  (binding [*out* *err*]
    (println (pr-str (select-keys @summary [:files :bytes])))))
