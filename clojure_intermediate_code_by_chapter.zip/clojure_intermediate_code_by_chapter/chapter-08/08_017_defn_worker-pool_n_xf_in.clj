(defn worker-pool [n xf in]
  (let [out (a/chan 1024 xf)]
    (a/pipeline-blocking n out (map identity) in)
