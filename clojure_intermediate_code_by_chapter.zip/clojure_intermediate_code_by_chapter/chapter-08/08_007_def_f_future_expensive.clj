(def f (future (expensive)))
(deref f 100 ::timeout)
