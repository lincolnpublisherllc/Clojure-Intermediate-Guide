;; Example
(doseq [w [1 2 4 8]]
  (time (println w (run {:root "/some/dir" :workers w}))))
