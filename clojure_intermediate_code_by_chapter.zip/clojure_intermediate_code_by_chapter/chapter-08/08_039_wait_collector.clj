;; wait collector
    (deref coll)
    ;; return summary
