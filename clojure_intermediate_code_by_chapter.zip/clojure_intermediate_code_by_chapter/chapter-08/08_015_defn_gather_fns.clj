(defn gather [fns]
  (let [fs (mapv future fns)]
    (mapv deref fs)))
