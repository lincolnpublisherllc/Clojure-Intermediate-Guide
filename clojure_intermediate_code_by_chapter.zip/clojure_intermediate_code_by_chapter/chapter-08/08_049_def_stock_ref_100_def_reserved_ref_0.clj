(def stock (ref 100)) (def reserved (ref 0))
(defn reserve! []
  (dosync (when (pos? @stock) (alter stock dec) (alter reserved inc))))
