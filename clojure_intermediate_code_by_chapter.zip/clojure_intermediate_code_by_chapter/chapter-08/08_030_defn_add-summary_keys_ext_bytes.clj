(defn add-summary! [{:keys [ext bytes]}]
  (swap! summary
         (fn [{:keys [by-ext] :as s}]
           (-> s
               (update :files inc)
               (update :bytes + bytes)
               (update :by-ext update ext (fnil (fn [{:keys [n b]}]
                                                  {:n (inc (or n 0))
                                                   :b (+ (or b 0) bytes)})
                                            {:n 0 :b 0}))))))
(defn mark-error! [] (swap! summary update :errors inc))
