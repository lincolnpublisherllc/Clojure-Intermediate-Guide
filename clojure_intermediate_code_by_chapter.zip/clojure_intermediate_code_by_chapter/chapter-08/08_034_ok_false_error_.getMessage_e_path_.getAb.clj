{:ok false :error (.getMessage e) :path (.getAbsolutePath f)}))))
        out-ch (a/chan buf step)
        ;; start workers
        _      (a/pipeline-blocking workers out-ch (map identity) in-ch)
