(defn safe-step [f]
  (fn [x]
    (try {:ok true :value (f x)}
         (catch Exception e {:ok false :error (.getMessage e) :x x}))))
