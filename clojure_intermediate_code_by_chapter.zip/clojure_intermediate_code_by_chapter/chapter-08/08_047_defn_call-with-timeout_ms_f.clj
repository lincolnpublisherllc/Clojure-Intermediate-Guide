(defn call-with-timeout [ms f]
  (let [ft (future (f))
        v  (deref ft ms ::timeout)]
    (if (= v ::timeout)
      (do (future-cancel ft) {:ok false :error :timeout})
      {:ok true :value v})))
