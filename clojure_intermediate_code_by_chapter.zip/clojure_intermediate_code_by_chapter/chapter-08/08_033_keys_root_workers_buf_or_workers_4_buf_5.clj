[{:keys [root workers buf] :or {workers 4 buf 512}}]
  (reset! summary {:files 0 :bytes 0 :by-ext {} :errors 0})
  (let [in-ch  (a/chan buf)
        ;; map step wrapped with error->data
        step   (map (fn [^java.io.File f]
                      (try {:ok true :value (file-info f)}
