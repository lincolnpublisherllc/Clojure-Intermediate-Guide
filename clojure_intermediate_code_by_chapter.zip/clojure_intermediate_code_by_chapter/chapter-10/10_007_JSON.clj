;; JSON
        cheshire/cheshire            {:mvn/version "5.12.0"}
