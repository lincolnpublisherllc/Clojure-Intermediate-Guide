(defn parse-json-body [req]
  (when-let [body (:body req)]
    (json/parse-string (slurp body) true)))
