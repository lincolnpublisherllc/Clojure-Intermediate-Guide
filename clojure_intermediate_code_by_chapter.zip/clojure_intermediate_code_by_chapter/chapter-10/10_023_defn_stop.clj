(defn stop! []
  (when-let [srv @!srv] (srv) (reset! !srv nil) :stopped))
Run: (start! {:port 3000}), then curl /health and /echo.
