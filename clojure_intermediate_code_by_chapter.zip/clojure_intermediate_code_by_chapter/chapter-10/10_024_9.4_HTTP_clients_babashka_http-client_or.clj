9.4 HTTP clients (babashka/http-client or clj-http)
