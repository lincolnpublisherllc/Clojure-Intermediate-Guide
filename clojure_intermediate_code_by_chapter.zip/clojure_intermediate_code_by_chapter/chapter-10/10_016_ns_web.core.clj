(ns web.core
  (:require [cheshire.core :as json]
            [clojure.string :as str]))
