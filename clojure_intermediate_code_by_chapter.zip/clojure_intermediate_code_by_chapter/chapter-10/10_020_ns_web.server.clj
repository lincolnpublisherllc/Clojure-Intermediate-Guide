(ns web.server
  (:require [org.httpkit.server :as http]
            [web.core :as core]))
