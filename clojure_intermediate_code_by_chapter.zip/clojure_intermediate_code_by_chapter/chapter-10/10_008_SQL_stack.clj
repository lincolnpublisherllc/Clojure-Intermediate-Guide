;; SQL stack
        com.github.seancorfield/next.jdbc {:mvn/version "1.3.939"}
        com.github.seancorfield/honeysql  {:mvn/version "2.6.1126"}
