;; HTTP server & client
        http-kit/http-kit            {:mvn/version "2.7.0"}
