(defn start! [{:keys [port] :or {port 8080}}]
  (reset! !srv (http/run-server core/routes {:port port}))
  (println "HTTP on" port)
