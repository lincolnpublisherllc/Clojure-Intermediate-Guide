9.2 Dependencies (example deps.edn)
