(defn routes [req]
  (case [(:request-method req) (:uri req)]
    [:get "/health"] (json-response {:ok true})
    [:post "/echo"]  (json-response {:you-sent (parse-json-body req)})
    (json-response {:error "not-found"} 404)))
