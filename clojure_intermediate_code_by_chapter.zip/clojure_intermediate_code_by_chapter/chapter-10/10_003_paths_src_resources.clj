{:paths ["src" "resources"]
