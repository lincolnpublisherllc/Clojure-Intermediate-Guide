;; CLI
        org.clojure/tools.cli        {:mvn/version "1.1.230"}
