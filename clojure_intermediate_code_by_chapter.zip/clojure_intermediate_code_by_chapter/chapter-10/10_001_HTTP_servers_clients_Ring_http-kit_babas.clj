HTTP servers/clients: Ring, http-kit, babashka/http-client (or clj-http)
