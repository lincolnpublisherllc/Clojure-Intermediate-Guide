{:app   {:exec-fn app.main/run}
  :dev   {}
  :test  {}
  :build {:deps {io.github.clojure/tools.build {:git/tag "v0.10.6" :git/sha "..."}} :ns-default build}}}
