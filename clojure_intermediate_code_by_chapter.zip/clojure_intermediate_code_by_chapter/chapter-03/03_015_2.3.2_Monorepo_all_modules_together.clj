2.3.2 Monorepo (all modules together)
