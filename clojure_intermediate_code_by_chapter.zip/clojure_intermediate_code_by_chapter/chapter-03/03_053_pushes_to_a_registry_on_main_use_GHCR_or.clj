pushes to a registry on main (use GHCR or your registry)
