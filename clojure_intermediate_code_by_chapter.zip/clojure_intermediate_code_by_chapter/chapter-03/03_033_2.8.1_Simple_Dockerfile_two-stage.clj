2.8.1 Simple Dockerfile (two-stage)
