deps.edn patterns with multiple aliases (:dev, :test, :bench, :uber, etc.)
