{:extra-paths ["test"]
    :extra-deps  {org.clojure/test.check {:mvn/version "1.1.1"}
                  lambdaisland/kaocha   {:mvn/version "1.88.1376"}}
    :main-opts   ["-m" "kaocha.runner"]}     ;; -M style (main class)
