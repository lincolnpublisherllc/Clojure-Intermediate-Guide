(ns ci.tasks
  (:require [clojure.java.shell :as sh]))
