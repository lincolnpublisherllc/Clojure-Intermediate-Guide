run: docker push ghcr.io/<org>/example-app:${{ github.sha }}
