Pinning versions for reproducibility (Maven and Git deps)
