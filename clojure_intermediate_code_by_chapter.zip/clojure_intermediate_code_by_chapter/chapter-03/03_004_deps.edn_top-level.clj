;; deps.edn (top-level)
{
  :paths ["src" "resources"]
