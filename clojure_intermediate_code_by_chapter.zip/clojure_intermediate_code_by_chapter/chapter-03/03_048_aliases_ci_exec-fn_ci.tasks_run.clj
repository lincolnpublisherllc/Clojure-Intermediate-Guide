:aliases {:ci {:exec-fn ci.tasks/run}}
