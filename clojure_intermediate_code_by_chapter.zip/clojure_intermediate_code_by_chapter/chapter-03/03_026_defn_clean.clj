(defn clean [_]
  (b/delete {:path "target"}))
