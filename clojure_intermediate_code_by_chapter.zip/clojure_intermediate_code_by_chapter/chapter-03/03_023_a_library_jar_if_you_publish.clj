a library jar (if you publish)
