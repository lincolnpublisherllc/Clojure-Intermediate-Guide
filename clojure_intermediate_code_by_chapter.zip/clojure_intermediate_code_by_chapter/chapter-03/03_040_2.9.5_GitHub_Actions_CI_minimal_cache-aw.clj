2.9.5 GitHub Actions CI (minimal, cache-aware)
