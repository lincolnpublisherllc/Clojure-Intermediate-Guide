{:dev
   {:extra-paths ["dev"]
    :extra-deps  {criterium/criterium {:mvn/version "0.4.6"}
                  org.clojure/tools.namespace {:mvn/version "1.4.4"}}
    :jvm-opts    ["-Dclojure.main.report=stderr"]}
