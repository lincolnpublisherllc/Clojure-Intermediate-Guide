2.10 Practical hands-on exercises (with solutions)
