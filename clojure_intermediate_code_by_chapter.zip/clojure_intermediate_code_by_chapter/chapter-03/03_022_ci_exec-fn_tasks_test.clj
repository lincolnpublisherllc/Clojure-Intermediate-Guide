{:ci    {:exec-fn tasks/test}
 :hello {:exec-fn tasks/greet :exec-args {:name "Clojure"}}}
