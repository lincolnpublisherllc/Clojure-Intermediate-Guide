(defn lint [_]
  (println "Running clj-kondo...")
  (let [{:keys [exit]} (sh/sh "clj" "-M:lint")]
    (System/exit exit)))
