(defn greet [{:keys [name]}]
  (println (str "Hello, " (or name "world") "!")))
