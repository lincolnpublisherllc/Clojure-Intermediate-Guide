CMD ["sh", "-lc", "exec java $JAVA_OPTS -jar /app/app.jar"]
