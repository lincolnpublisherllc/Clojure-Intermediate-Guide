:jar-file  (format "target/%s-%s.jar" (name lib) version)
