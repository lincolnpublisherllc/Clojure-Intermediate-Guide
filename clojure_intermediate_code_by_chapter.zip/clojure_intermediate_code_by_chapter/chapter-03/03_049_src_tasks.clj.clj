;; src/tasks.clj
(ns tasks
  (:require [clojure.java.shell :as sh]))
