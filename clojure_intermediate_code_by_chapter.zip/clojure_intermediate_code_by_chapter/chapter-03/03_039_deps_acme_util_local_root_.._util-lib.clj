:deps {acme/util {:local/root "../util-lib"}}
