(defn handler [_]
  {:status 200 :headers {"Content-Type" "text/plain"} :body "ok"})
