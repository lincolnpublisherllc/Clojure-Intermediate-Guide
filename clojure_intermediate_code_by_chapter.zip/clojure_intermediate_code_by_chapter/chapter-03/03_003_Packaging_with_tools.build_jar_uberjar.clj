Packaging with tools.build (jar/uberjar)
