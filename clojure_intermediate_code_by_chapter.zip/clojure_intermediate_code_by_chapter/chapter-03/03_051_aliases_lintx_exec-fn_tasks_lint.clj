:aliases {:lintx {:exec-fn tasks/lint}}
