(defn run [_]
  (sh! "clj" "-M:test")
  (sh! "clj" "-T:build" "uber"))
