{org.clojure/clojure {:mvn/version "1.11.3"}
   org.clojure/data.csv {:mvn/version "1.1.0"}
   ;; app deps
   http-kit/http-kit    {:mvn/version "2.7.0"}}
