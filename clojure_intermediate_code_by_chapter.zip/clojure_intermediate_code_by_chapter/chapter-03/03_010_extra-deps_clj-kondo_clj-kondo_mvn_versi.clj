{:extra-deps {clj-kondo/clj-kondo {:mvn/version "2024.07.29"}}
    :main-opts  ["-m" "clj-kondo.main" "--lint" "src" "test"]}
