:deps {my/lib-a {:local/root "../lib-a"}}
