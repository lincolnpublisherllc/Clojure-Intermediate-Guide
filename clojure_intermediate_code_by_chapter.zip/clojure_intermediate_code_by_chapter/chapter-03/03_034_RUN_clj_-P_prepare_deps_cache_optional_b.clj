RUN clj -P  # prepare deps cache (optional but speeds up subsequent runs)
