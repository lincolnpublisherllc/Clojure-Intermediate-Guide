(defn sh! [& args]
  (let [{:keys [exit out err]} (apply sh/sh args)]
    (when (pos? exit)
      (throw (ex-info (str "Command failed: " (pr-str args))
                      {:exit exit :out out :err err})))
    (println out)))
