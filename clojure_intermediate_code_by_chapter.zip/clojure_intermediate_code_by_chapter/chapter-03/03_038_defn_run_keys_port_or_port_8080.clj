(defn run [{:keys [port] :or {port 8080}}]
  (println "Starting on" port)
  (http/run-server handler {:port port})
  (println "Press Ctrl-C to stop")
  (Thread/sleep Long/MAX_VALUE))
