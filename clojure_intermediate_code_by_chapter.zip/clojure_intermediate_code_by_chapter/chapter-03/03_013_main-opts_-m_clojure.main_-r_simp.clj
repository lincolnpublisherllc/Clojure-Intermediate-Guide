{:main-opts ["-m" "clojure.main" "-r"]}}   ;; simple repl alias
